INSERT INTO user_access."user" (id, username, password, name, gender, is_admin, birthday, phone_num, home_address)
VALUES (-1, 'admin', '$2a$04$VVq0qDUIYovu7.xbPo9P0ODeFTGzkVEm4VMLNEBsLYBcjUsWj0tBO', 'admin', 2, true,
        '2021-05-23 00:00:00.000', '00000000000', 'Dalian China');