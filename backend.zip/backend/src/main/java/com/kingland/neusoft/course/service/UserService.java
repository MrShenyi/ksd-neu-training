package com.kingland.neusoft.course.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.kingland.neusoft.course.config.PasswordEncoderConfig;
import com.kingland.neusoft.course.mapper.UserMapper;
import com.kingland.neusoft.course.mapper.dao.UserModel;
import com.kingland.neusoft.course.vo.UserPageListVO;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation class of user service
 *
 * @author KSC
 */
@Service
public class UserService {

    //    @Autowired
    private final UserMapper userMapper;
    //    @Autowired
    private final PasswordEncoder passwordEncoder;

    public UserService(UserMapper userMapper, PasswordEncoder passwordEncoder) {
        this.userMapper = userMapper;
        this.passwordEncoder = passwordEncoder;
    }

    public UserModel addUser(UserModel userModel) {
        /** encode raw password string before inserting to the database
         * the encode provided in {@link PasswordEncoderConfig#passwordEncoder}
         **/
        userModel.setPassword(this.passwordEncoder.encode(userModel.getPassword()));
        userMapper.insert(userModel);
        return userModel;
    }

    public Integer countUser() {
        return userMapper.count();
    }

    public UserModel getUserById(Long userId) {
        return userMapper.selectByPrimaryKey(userId);
    }

    public List<UserModel> getAllUser() {
        return this.userMapper.query();
    }

    public int deleteUser(Long userId) {
        return this.userMapper.deleteByPrimaryKey(userId);
    }

    public int updateUser(UserModel userModel) {
        userModel.setPassword(this.passwordEncoder.encode(userModel.getPassword()));
        return userMapper.updateByPrimaryKeySelective(userModel);
    }

    public Map<String,Object> userPageList(UserPageListVO userPageListVO) {
        int  currIndex = (userPageListVO.getPageNum() - 1) * userPageListVO.getPageSize();
        int  pageSize = userPageListVO.getPageSize();
        Map<String,Object> map = new HashMap<>();
        map.put("pageNum",userPageListVO.getPageNum());
        map.put("pageSize",userPageListVO.getPageSize());
        map.put("data",userMapper.queryByCondition(currIndex,pageSize, userPageListVO.getId(),userPageListVO.getUsername(),userPageListVO.getPhoneNum()));
        return map;

    }
}
