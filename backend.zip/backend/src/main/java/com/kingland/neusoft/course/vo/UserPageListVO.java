package com.kingland.neusoft.course.vo;

public class UserPageListVO extends PageListVO{

    private Long id;

    private String username;

    private String phoneNum;

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPhoneNum() {
        return phoneNum;
    }
}
