package com.kingland.neusoft.course.vo;

public class PageListVO {
    private int pageNum=1;
    private int pageSize=10;

    public int getPageNum() {
        return pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }
}
